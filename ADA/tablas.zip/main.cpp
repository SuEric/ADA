//
//  main.cpp
//  ADA
//
//  Created by sueric on 01/07/14.
//  Copyright (c) 2014 SuEric. All rights reserved.
//

#include <iostream>
#include <string>

#include "Lista.h"
#include "TablaHash.h"


int main(int argc, const char * argv[])
{
    TablaHash tablaHash(10);
    tablaHash.construirTabla();
    
//    string palabra1, palabra2, palabra3;

//    palabra1 = "hola";
//    palabra2 = "como";
//    palabra3 = "dedo";
    
//    tablaHash.cargarTablaIndice(palabra1, "prueba1.txt");
//    tablaHash.cargarTablaIndice(palabra2, "prueba2.txt");
//    tablaHash.cargarTablaIndice(palabra3, "prueba3.txt");
    
//    tablaHash.mostrar(palabra1);
//    tablaHash.mostrar(palabra2);
//    tablaHash.mostrar(palabra3);
    
//    tablaHash.mostrar("dolor");
//    tablaHash.guardarTablaIndice("dolor");
    
//    tablaHash.cargarTablaIndice("dolor");
    tablaHash.mostrarLista("i");
    
//    tablaHash.mostrarElemento("dolor");
    /*
    list_1.insertarOrd(palabra1, documentos1);
    list_1.insertarOrd(palabra2, documentos3);
    list_1.insertarOrd(palabra3, documentos3);
    list_1.imprimir();*/
    
    return 0;
}

