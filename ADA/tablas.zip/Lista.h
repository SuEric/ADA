//
//  Listaa.h
//  ADA
//
//  Created by sueric on 04/07/14.
//  Copyright (c) 2014 SuEric. All rights reserved.
//

#ifndef __ADA__Listaa__
#define __ADA__Listaa__

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

#include "Nodo.h"

class Lista {
public:
    Lista();
    ~Lista();
    
    void insertarOrd(string, string);
    void borrarLista();
    void imprimir();
    bool existe(string);
    Nodo *buscar(string);
    void ordenar();
    void guardarArchivo(string);
    void cargarArchivo(string);
private:
    Nodo *inicio;
    int num_nodos;
};

#endif /* defined(__ADA__Listaa__) */
